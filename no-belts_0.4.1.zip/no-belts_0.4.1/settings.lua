data:extend{
    {
        type = "bool-setting",
        name = "give-quickstart-parmor",
        setting_type = "startup",
        default_value = false
    },
    {
        type = "bool-setting",
        name = "give-quickstart-stuff",
        setting_type = "startup",
        default_value = false
    },
    {
        type = "int-setting",
        name = "robot-costs-multipler",
        setting_type = "startup",
        default_value = 1
    }
}